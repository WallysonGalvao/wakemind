import { requireNativeView } from 'expo';
import * as React from 'react';

import { ExpoAlarmActivityViewProps } from './ExpoAlarmActivity.types';

const NativeView: React.ComponentType<ExpoAlarmActivityViewProps> =
  requireNativeView('ExpoAlarmActivity');

export default function ExpoAlarmActivityView(props: ExpoAlarmActivityViewProps) {
  return <NativeView {...props} />;
}
