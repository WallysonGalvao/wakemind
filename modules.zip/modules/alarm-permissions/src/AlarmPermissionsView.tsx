import { requireNativeView } from 'expo';
import * as React from 'react';

import { AlarmPermissionsViewProps } from './AlarmPermissions.types';

const NativeView: React.ComponentType<AlarmPermissionsViewProps> =
  requireNativeView('AlarmPermissions');

export default function AlarmPermissionsView(props: AlarmPermissionsViewProps) {
  return <NativeView {...props} />;
}
