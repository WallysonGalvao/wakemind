import { registerWebModule, NativeModule } from 'expo';

import { ChangeEventPayload } from './AlarmPermissions.types';

type AlarmPermissionsModuleEvents = {
  onChange: (params: ChangeEventPayload) => void;
}

class AlarmPermissionsModule extends NativeModule<AlarmPermissionsModuleEvents> {
  PI = Math.PI;
  async setValueAsync(value: string): Promise<void> {
    this.emit('onChange', { value });
  }
  hello() {
    return 'Hello world! 👋';
  }
};

export default registerWebModule(AlarmPermissionsModule, 'AlarmPermissionsModule');
