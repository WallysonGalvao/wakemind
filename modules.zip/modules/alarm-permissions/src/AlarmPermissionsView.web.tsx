import * as React from 'react';

import { AlarmPermissionsViewProps } from './AlarmPermissions.types';

export default function AlarmPermissionsView(props: AlarmPermissionsViewProps) {
  return (
    <div>
      <iframe
        style={{ flex: 1 }}
        src={props.url}
        onLoad={() => props.onLoad({ nativeEvent: { url: props.url } })}
      />
    </div>
  );
}
