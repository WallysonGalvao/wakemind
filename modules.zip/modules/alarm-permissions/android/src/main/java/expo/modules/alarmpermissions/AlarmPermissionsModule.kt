package expo.modules.alarmpermissions

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import expo.modules.kotlin.Promise
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class AlarmPermissionsModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("AlarmPermissions")

    // Check if app can draw overlays (SYSTEM_ALERT_WINDOW permission)
    AsyncFunction("canDrawOverlays") { promise: Promise ->
      try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          val canDraw = AndroidSettings.canDrawOverlays(appContext.reactContext)
          promise.resolve(canDraw)
        } else {
          // Permission granted by default on older Android versions
          promise.resolve(true)
        }
      } catch (e: Exception) {
        promise.reject("ERROR", "Failed to check overlay permission", e)
      }
    }

    // Open system settings for overlay permission
    AsyncFunction("openSettings") { promise: Promise ->
      try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          val intent = Intent(
            AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + appContext.reactContext?.packageName)
          )
          intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          appContext.reactContext?.startActivity(intent)
          promise.resolve(true)
        } else {
          promise.resolve(false)
        }
      } catch (e: Exception) {
        promise.reject("ERROR", "Failed to open overlay settings", e)
      }
    }

    // Open manufacturer-specific auto-start settings
    AsyncFunction("openAutoStartSettings") { promise: Promise ->
      try {
        val manufacturer = Build.MANUFACTURER.lowercase()
        val intent = when {
          // Xiaomi
          manufacturer.contains("xiaomi") -> {
            Intent().apply {
              component = ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
              )
            }
          }
          // Huawei
          manufacturer.contains("huawei") -> {
            Intent().apply {
              component = ComponentName(
                "com.huawei.systemmanager",
                "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
              )
            }
          }
          // Oppo
          manufacturer.contains("oppo") -> {
            Intent().apply {
              component = ComponentName(
                "com.coloros.safecenter",
                "com.coloros.safecenter.permission.startup.StartupAppListActivity"
              )
            }
          }
          // Vivo
          manufacturer.contains("vivo") -> {
            Intent().apply {
              component = ComponentName(
                "com.vivo.permissionmanager",
                "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
              )
            }
          }
          // Samsung (One UI)
          manufacturer.contains("samsung") -> {
            Intent().apply {
              component = ComponentName(
                "com.samsung.android.lool",
                "com.samsung.android.sm.ui.battery.BatteryActivity"
              )
            }
          }
          // Fallback: Open app info
          else -> {
            Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
              data = Uri.parse("package:" + appContext.reactContext?.packageName)
            }
          }
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        appContext.reactContext?.startActivity(intent)
        promise.resolve(true)
      } catch (e: Exception) {
        // If specific settings fail, fallback to app info
        try {
          val fallbackIntent = Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:" + appContext.reactContext?.packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          }
          appContext.reactContext?.startActivity(fallbackIntent)
          promise.resolve(true)
        } catch (fallbackError: Exception) {
          promise.reject("ERROR", "Failed to open auto-start settings", e)
        }
      }
    }

    // Get device manufacturer
    AsyncFunction("getManufacturer") { promise: Promise ->
      try {
        promise.resolve(Build.MANUFACTURER)
      } catch (e: Exception) {
        promise.reject("ERROR", "Failed to get manufacturer", e)
      }
    }
  }
}
