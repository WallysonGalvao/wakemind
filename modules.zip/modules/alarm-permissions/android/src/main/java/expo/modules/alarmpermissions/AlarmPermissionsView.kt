package expo.modules.alarmpermissions

import android.content.Context
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.views.ExpoView

// This view is not used in this module
// Kept as placeholder for future use if needed
class AlarmPermissionsView(context: Context, appContext: AppContext) : ExpoView(context, appContext)
