// Reexport the native module. On web, it will be resolved to AlarmPermissionsModule.web.ts
// and on native platforms to AlarmPermissionsModule.ts
export { default } from './src/AlarmPermissionsModule';
export { default as AlarmPermissionsView } from './src/AlarmPermissionsView';
export * from  './src/AlarmPermissions.types';
